import {
  playMoveSound,
  playCaptureSound,
  playCheckSound,
} from "../../sounds.js";

export interface GameMeta {
  _id: string;
  joinCode: string;
  variant: "standard" | "chess960";
  initialFen: string;
  white: { _id: string; username: string; avatarGradient?: any; rating?: number | null; ratingCategory?: string | null } | null;
  black: { _id: string; username: string; avatarGradient?: any; rating?: number | null; ratingCategory?: string | null } | null;
  status: "waiting" | "active" | "finished" | "aborted";
  timeControl: { baseSeconds: number | null; incrementSeconds: number };
  wagerTokens?: number;
  cageMatchId?: string | null;
  legIndex?: number | null;
  /** Set by mongoose timestamps, used for the PGN export's [Date] tag
   *  (see chessUtils.ts's buildPgn / Game.tsx's handleCopyPgn). */
  createdAt: string;
  /** Populated with just the join code by getGameByCode, enough for a
   *  "Back to tournament" link without pulling the whole Tournament doc. */
  /** Populated with the join code (for the "Back to tournament" link),
   *  name (shown on the in-game badge), and — for formats that have a
   *  fixed duration — format + arenaMinutes, so the game page can show a
   *  duration badge (see Game.tsx's badges list). arenaMinutes is null
   *  for every non-arena format, and for arena tournaments started
   *  without an explicit duration (defaults to 60 server-side at start,
   *  but the field itself can still be null before then). */
  tournamentId?: {
    _id: string;
    code: string;
    name: string;
    format: "normal" | "swiss" | "round_robin" | "arena";
    status: "pending" | "active" | "finished" | "cancelled";
    arenaMinutes: number | null;
    // Set once the arena tournament actually starts (see the server's
    // ITournament doc comment) — always non-null in practice by the time
    // a game page exists for one, since a game only gets created once
    // pairing is live. Drives the live countdown badge in Game.tsx;
    // arenaMinutes above is just the fallback while it's still null.
    // Once the arena finishes this is a fixed timestamp in the past
    // forever, so the badge also needs `status` to know to stop showing
    // rather than reading it as still counting down.
    arenaEndsAt: string | null;
  } | null;
}

export interface MoveLogEntry {
  moveNumber: number;
  san: string;
  from: string;
  to: string;
  /** Server timestamp of when this move landed, present for every move
   *  of a finished game (persisted) and, live, for any move made from
   *  this point in the socket connection onward (see gameSocket.ts's
   *  game:move payload). Missing only for moves that arrived over an
   *  older live session before this field existed to persist, treat as
   *  optional everywhere it's consumed (see reconstructPlyClocks). */
  timestampMs?: number;
}

export type Role = "white" | "black" | "spectator";

export interface RatingSideUpdate {
  previousCategory: string | null;
  newCategory: string | null;
  ratedGamesPlayed: number;
  /** Rating points gained/lost this game, positive or negative. */
  delta: number;
  /** The player's actual rating after this game. */
  newRating: number;
  /** Points left to the next tier after this game, null if unranked or
   *  already at the top tier. */
  pointsToNextTier: { points: number; nextTierName: string } | null;
  /** Mirrors gamesUntilRanked(ratedGamesPlayed) on the server, for the
   *  "Unranked, N more games to go" message when newCategory is still
   *  null after this game. */
  ratedGamesUntilRanked: number;
}

export interface RatingUpdate {
  white: RatingSideUpdate;
  black: RatingSideUpdate;
}

export interface WagerSettlement {
  wagerTokens: number;
  potTokens: number;
  winnerId: string | null;
  payoutTokens: number;
  rakeTokens: number;
}

/** A game is only ever "live", i.e. worth opening a socket room for, 
 *  while it's waiting for an opponent or actually being played. Once it's
 *  finished or aborted there's nothing left to sync in real time, so
 *  those two statuses are the "stale" side of the fixed /game/:code URL:
 *  same page, same layout, just filled in from the one-shot REST payload
 *  instead of a socket connection. See the fetch effect in Game.tsx. */
export function isLiveStatus(status: GameMeta["status"]) {
  return status === "waiting" || status === "active";
}

/** Picks the same check/capture/plain-move sound for a SAN string
 *  regardless of where the move came from, a live game:move event or
 *  just walking the move list during replay. Shared so the two call
 *  sites can't quietly drift apart.
 *
 *  A mating move ("#") is deliberately NOT treated as a check here even
 *  though "+"/"#" share the same "king in check" SAN marker — checkmate
 *  ends the game outright, and that moment already gets its own
 *  dedicated game-over sound (see Game.tsx's onOver handler /
 *  playGameOverSound) moments later on the live path. Playing the check
 *  sound too would announce "check!" immediately before "game over" for
 *  what's really a single event. So a mating move instead falls through
 *  to its capture/plain-move sound (still audible when just browsing a
 *  finished game's move list, where there's no separate game-over event
 *  to hand off to), leaving the check sound exclusively for a check that
 *  doesn't end the game. */
export function playSoundForMove(san: string | undefined) {
  if (!san) return;
  if (san.includes("#")) {
    if (san.includes("x")) playCaptureSound();
    else playMoveSound();
  } else if (san.includes("+")) {
    playCheckSound();
  } else if (san.includes("x")) {
    playCaptureSound();
  } else {
    playMoveSound();
  }
}

export function describeResult(result: string | null): string {
  if (result === "white") return "White wins";
  if (result === "black") return "Black wins";
  if (result === "draw") return "Draw";
  return "Game aborted";
}
