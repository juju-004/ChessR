import { createServer } from 'http';
import { env } from './config/env.js';
import { connectMongo, disconnectMongo } from './config/db.js';
import { disconnectRedis } from './config/redis.js';
import { createApp } from './app.js';
import { initSocketServer } from './sockets/index.js';
import { getIo } from './sockets/io.js';
import { reconcileActiveGames, sweepAbortedGames } from './services/game.service.js';
import { reconcileActiveTournaments, sweepCancelledTournaments, resolveDesyncedArenaPairings } from './services/tournament.service.js';
import { reconcilePresence } from './services/presence.service.js';
import { runAllQuickPairingPasses } from './services/quickPairing.service.js';
import { broadcastLobbyCounts } from './sockets/quickPairingSocket.js';
import { FriendRequest } from './models/FriendRequest.js';
import { Game } from './models/Game.js';

async function main() {
  await connectMongo();

  // Self-heals a schema change: FriendRequest's unique index used to be a
  // blanket {from, to} unique index; it's now partial, scoped to pending
  // requests only, so a resolved request no longer permanently blocks a
  // fresh one between the same two people (see FriendRequest.ts).
  // Mongoose's autoIndex creates newly-defined indexes on boot but won't
  // drop a conflicting old one on its own, a database that already had
  // the old index just keeps silently enforcing it forever, defeating the
  // fix, hence this. syncIndexes drops anything not in the current schema
  // and creates what's missing; idempotent and cheap once already in
  // sync, so it's fine to just run on every boot rather than needing a
  // one-off migration script someone has to remember to run.
  await FriendRequest.syncIndexes().catch((err) => {
    console.error('FriendRequest.syncIndexes failed:', err);
  });

  // Same reasoning as FriendRequest above: guarantees the two indexes
  // getUserGames needs (see Game.ts) actually get built on deploy rather
  // than relying on autoIndex alone. On a games collection that's already
  // grown a fair amount, building these for the first time isn't
  // instant — MongoDB does it in the background without blocking reads or
  // writes, but the old, slow, unindexed query plan is still what serves
  // requests until the build finishes.
  await Game.syncIndexes().catch((err) => {
    console.error('Game.syncIndexes failed:', err);
  });

  const app = createApp();
  const httpServer = createServer(app);

  initSocketServer(httpServer);

  // Recover any games whose in-memory clock timer was wiped out by the process
  // restarting (very common in dev with hot-reload; also a real concern in
  // prod after a deploy or crash). Then keep sweeping periodically as a
  // general safety net.
  reconcileActiveGames()
    .then(({ resumed, timedOut, aborted, idleCancelled }) => {
      if (resumed || timedOut || aborted || idleCancelled) {
        console.log(
          `♟️  Reconciled active games on boot: ${resumed} resumed, ${timedOut} timed out, ${aborted} aborted (no live state), ${idleCancelled} cancelled (idle too long).`,
        );
      }
    })
    .catch((err) => console.error('reconcileActiveGames failed on boot:', err));

  // Same idea as reconcileActiveGames, but for tournaments sitting in their
  // inter-round break, recovers any in-memory break timer wiped out by a
  // restart (see scheduleRoundStart in tournament.service.ts).
  reconcileActiveTournaments()
    .then(({ activated, rearmed, autoStarted, autoStartRearmed }) => {
      if (activated || rearmed || autoStarted || autoStartRearmed) {
        console.log(
          `🏆 Reconciled tournaments on boot: ${activated} round(s) activated, ${rearmed} break(s) re-armed, ${autoStarted} auto-started, ${autoStartRearmed} auto-start(s) re-armed.`,
        );
      }
    })
    .catch((err) => console.error('reconcileActiveTournaments failed on boot:', err));

  // Self-heal for "some users show online when they're not" (see
  // reconcilePresence's own doc comment — traced to a Redis outage/quota
  // limit leaving stale presence entries stuck forever). Also fixes
  // whichever users are already stuck this way as of this deploy.
  reconcilePresence(getIo())
    .then(({ prunedSockets }) => {
      if (prunedSockets) console.log(`🔧 Pruned ${prunedSockets} stale presence socket(s) on boot.`);
    })
    .catch((err) => console.error('reconcilePresence failed on boot:', err));

  // Self-heal for the "stuck on Finishing up…" arena incident (see
  // resolveDesyncedArenaPairings' own doc comment): catches an arena
  // tournament left "active" forever because a pairing's game finished but
  // never made it back into the tournament document.
  resolveDesyncedArenaPairings()
    .then(({ resolved }) => {
      if (resolved) console.log(`🔧 Repaired ${resolved} desynced arena pairing(s) on boot.`);
    })
    .catch((err) => console.error('resolveDesyncedArenaPairings failed on boot:', err));

  // Cancelled tournaments carry no lasting value (no games were ever
  // played), so they're deleted a short while after cancellation rather
  // than accumulating forever, see sweepCancelledTournaments' own comment
  // for the grace-period reasoning.
  sweepCancelledTournaments()
    .then(({ deleted }) => {
      if (deleted) console.log(`🗑️  Swept ${deleted} cancelled tournament(s) on boot.`);
    })
    .catch((err) => console.error('sweepCancelledTournaments failed on boot:', err));

  // Same idea, for standalone aborted games (see sweepAbortedGames' own
  // comment for what's excluded and why).
  sweepAbortedGames()
    .then(({ deleted }) => {
      if (deleted) console.log(`🗑️  Swept ${deleted} aborted game(s) on boot.`);
    })
    .catch((err) => console.error('sweepAbortedGames failed on boot:', err));

  // Runs much more often than IDLE_PHASE_ABANDON_MS (5 min, in game.service.ts)
  // on purpose, if this ran every 5 minutes too, a game that just missed one
  // sweep could sit idle for close to double the intended threshold before
  // getting caught. A 60s cadence bounds that worst case to ~1 extra minute
  // instead, while still being cheap (Game.find({status:'active'}) over a
  // realistic table size, once a minute).
  const reconcileInterval = setInterval(() => {
    reconcileActiveGames().catch((err) => console.error('periodic reconcileActiveGames failed:', err));
    reconcileActiveTournaments().catch((err) => console.error('periodic reconcileActiveTournaments failed:', err));
    resolveDesyncedArenaPairings().catch((err) => console.error('periodic resolveDesyncedArenaPairings failed:', err));
    reconcilePresence(getIo()).catch((err) => console.error('periodic reconcilePresence failed:', err));
    sweepCancelledTournaments().catch((err) => console.error('periodic sweepCancelledTournaments failed:', err));
    sweepAbortedGames().catch((err) => console.error('periodic sweepAbortedGames failed:', err));
  }, 60 * 1000);
  reconcileInterval.unref();

  // Quick pairing needs a much tighter cadence than the 60s sweeps above:
  // it's what widens a waiting player's rating window over time, and what
  // pairs anyone a fresh join didn't already match instantly.
  const quickPairingInterval = setInterval(() => {
    runAllQuickPairingPasses()
      .then(() => broadcastLobbyCounts(getIo()))
      .catch((err) => console.error('periodic quick pairing pass failed:', err));
  }, 2000);
  quickPairingInterval.unref();

  httpServer.listen(env.PORT, () => {
    console.log(`🚀 Server listening on port ${env.PORT} [${env.NODE_ENV}]`);
  });

  const shutdown = async (signal: string) => {
    console.log(`\n${signal} received. Shutting down gracefully...`);
    // httpServer.close()'s callback only fires once every connection on it
    // has ended, and open WebSocket connections don't end on their own, so
    // with even one player still connected that callback would never fire.
    // That used to mean disconnectRedis() never ran, and the process was
    // killed 10s later by the force-exit below instead, a hard cut that
    // left the Redis adapter's pub/sub subscriber connections still open
    // from Redis's point of view. The next deploy's instance would then
    // wait on fetchSockets() replies from this now-dead instance until
    // Redis itself noticed the connection was gone, well past the
    // adapter's own request timeout, surfacing as spurious "timeout
    // reached while waiting for fetchSockets response" errors.
    // io.close() force-disconnects every socket immediately and lets the
    // Redis adapter unsubscribe cleanly, so it's called first and
    // unconditionally rather than nested inside httpServer.close()'s
    // callback.
    getIo().close();
    httpServer.close();
    // Force-exit if the cleanup below hangs for some other reason. Scheduled
    // up front, not after the awaited cleanup, so it actually guards against
    // a hang rather than only running once the hang is already over.
    const forceExit = setTimeout(() => process.exit(1), 10000);
    forceExit.unref();
    await Promise.all([disconnectMongo(), disconnectRedis()]);
    clearTimeout(forceExit);
    process.exit(0);
  };

  process.on('SIGINT', () => void shutdown('SIGINT'));
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
}

main().catch((err) => {
  console.error('❌ Failed to start server:', err);
  process.exit(1);
});
